# Oar Measurement System - LaTeX Source Files

## Structure

```
oar_latex_only/
├── oar_measurement_system_specification.tex  (MASTER)
└── sections/
    ├── 01_overview.tex
    ├── 02_coordinate_system.tex
    ├── 03_oar_geometry.tex
    ├── 04_beam_geometry.tex
    ├── 05_materials.tex
    ├── 06_strain_gauges.tex
    ├── 07_operating_conditions.tex
    ├── 08_theoretical_framework.tex
    ├── 09_analysis_sections.tex
    ├── 10_open_questions.tex
    ├── 11_nomenclature.tex
    └── 12_references.tex
```

## Compile

```bash
pdflatex oar_measurement_system_specification.tex
pdflatex oar_measurement_system_specification.tex  # Run twice for cross-references
```

## Required Packages

- amsmath, amssymb
- booktabs
- siunitx
- graphicx
- hyperref

Author: Sylvain Boyer (Mecafrog.com)
